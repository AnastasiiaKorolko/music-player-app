# Music Tracks Management App

## Description
This project is a web application for managing music tracks. You can create, edit, upload, and delete tracks, as well as view a list of tracks with the ability to filter, sort, and search.

This application is built using React, and React Query is used to manage the state and API requests. The app uses modals for creating and editing tracks, and it integrates with an API to save and retrieve track data. For the search functionality, **debounce** is implemented to ensure that the search queries are processed efficiently without excessive API calls.

A **scroll-to-header button** has been added for better navigation. It becomes visible when the user scrolls down the page and smoothly scrolls back to the top when clicked.

## Getting Started

### 1. Installation

1. Clone the repository to your local machine:

    ```bash
    git clone <repository-url>
    cd <project-folder>
    ```

2. Install dependencies:

    ```bash
    npm install
    ```

### 2. Running the App

1. Run the API server:

    Instructions for starting the API server are provided in the given documentation.

2. Run the frontend:

    ```bash
    npm start
    ```

3. The app will be available at:

    [http://localhost:3000](http://localhost:3000)

### 3. API Documentation

The API documentation is available at:

[http://localhost:8000/documentation](http://localhost:8000/documentation)

## Features

### Main Tasks

1. **Create a Track (without file upload)**:
   - Open a modal to create a track.
   - A form to input track metadata (e.g., title, artist, album, genres).
   - Validation for required fields.
   - Add a field for a cover image link with validation.
   - Display a default image for tracks without a cover.

2. **Edit Track Metadata**:
   - Open a modal to edit an existing track.
   - Pre-fill the form with current track metadata.
   - Save changes to the API and update the track list.

3. **Upload a Track (file)**:
   - Add functionality to upload an audio file (e.g., MP3, WAV) for an existing track.
   - Validate file type and size.
   - Allow replacing the file with a higher-quality version.
   - Use the HTML audio element to play the uploaded file.

4. **Delete a Track**:
   - Implement a feature to delete a track both from the UI and backend.

5. **Track List with Pagination, Sorting, and Filtering**:
   - Display a list of tracks with pagination for large datasets.
   - Sort by track title, artist, or genre.
   - Filter by artist and genre.
   - Implement a **search** feature with **debounce** to search by title, artist, or album, ensuring efficient API calls.

6. **Scroll-to-Header Button**:
   - Adds a floating button that appears when the user scrolls down the page.
   - Smoothly scrolls back to the header when clicked for better UX.

### Extra Tasks (Optional)

1. Implement bulk delete functionality (select multiple or all tracks to delete).
2. Implement optimistic updates to reflect changes in the UI before they are confirmed by the server.
3. Add audio wave visualization for the currently played track.

## Testing

### Setup Instructions

1. Ensure you have Node.js version `v20.13.1`.
2. Run the following commands to set up the project:

   ```bash
   npm install
   npm start
