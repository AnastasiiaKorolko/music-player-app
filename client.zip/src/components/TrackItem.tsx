import React, { useState } from 'react';
import { Track } from '../types/Track';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { uploadTrackFile, removeTrackFile } from '../api/tracksApi';
import styles from './TrackItem.module.css';

interface TrackItemProps {
  track: Track;
  onEdit: (track: Track) => void;
  onDelete: (id: string) => void;
}

const TrackItem: React.FC<TrackItemProps> = ({ track, onEdit, onDelete }) => {
  const { title, artist, album, genres, coverImage, id, audioFile='' } = track;
  const [isPlaying, setIsPlaying] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [imageError, setImageError] = useState(false);
  
  const queryClient = useQueryClient();
  
  const uploadMutation = useMutation({
    mutationFn: (file: File) => uploadTrackFile(id, file),
    onSuccess: () => {
      queryClient.invalidateQueries(['tracks']);
      setIsUploading(false);
    }
  });
  
  const removeFileMutation = useMutation({
    mutationFn: () => removeTrackFile(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['tracks']);
    }
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
  
    if (!file) return;
  
    const allowedTypes = ['audio/mpeg', 'audio/wav', 'audio/mp3', 'audio/x-wav'];
    const maxSize = 10 * 1024 * 1024;
  
    if (!allowedTypes.includes(file.type)) {
      alert('Unsupported file type. Please upload MP3 or WAV files.');
      return;
    }

    if (file.size > maxSize) {
      alert('File is too large. Maximum size is 10MB.');
      return;
    }
  
    setIsUploading(true);
    uploadMutation.mutate(file);
  };
  
  const handleRemoveFile = () => {
    removeFileMutation.mutate();
  };

  const defaultCoverImage = "https://via.placeholder.com/150?text=No+Image";

  return (
    <div className={styles.trackItem} data-testid={`track-item-${id}`}>
      <div className={styles.coverImage}>
        <img 
          src={imageError ? defaultCoverImage : (coverImage || defaultCoverImage)} 
          alt={title}
          onError={() => setImageError(true)}
        />
      </div>
      
      <div className={styles.trackInfo}>
        <h3 data-testid={`track-item-${id}-title`}>{title}</h3>
        <p data-testid={`track-item-${id}-artist`}>{artist}</p>
        {album && <p>{album}</p>}

        <div className={styles.genres}>
          {genres.map((genre, index) => (
            <span key={index} className={styles.genre}>{genre}</span>
          ))}
        </div>
      </div>
      
      <div className={styles.audioPlayer}>
        {audioFile ? (
          <div data-testid={`audio-player-${id}`}>
            <audio
              src={`/uploads/${audioFile}`}
              controls
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />
            <button 
              onClick={handleRemoveFile}
              className={styles.removeFileBtn}
            >
              Remove audio
            </button>
          </div>
        ) : (
          <div className={styles.uploadArea}>
            <input
              type="file"
              accept="audio/*"
              onChange={handleFileUpload}
              id={`upload-${id}`}
              style={{ display: 'none' }}
            />
            <label htmlFor={`upload-${id}`} className={styles.uploadButton} data-testid={`upload-track-${id}`}>
              {isUploading ? 'Uploading...' : 'Upload audio'}
            </label>
          </div>
        )}
      </div>
      
      <div className={styles.actions}>
        <button
          onClick={() => onEdit(track)}
          className={styles.editButton}
          data-testid={`edit-track-${id}`}
        >
          Edit
        </button>
        <button
          onClick={() => onDelete(id)}
          className={styles.deleteButton}
          data-testid={`delete-track-${id}`}
        >
          Remove
        </button>
      </div>
    </div>
  );
};

export default TrackItem;
